import React, { useState } from 'react'
import "../Styles/List.css"
import ModalUpdate from './ModalUpdate';


function AdminList() {
    let localStore = JSON.parse(localStorage.getItem('products'));
    const [products, setProducts] = useState(localStore);
    const [modal, setModal] = useState(false);
    const [data, setData] = useState({});
    const [idData, setIdData] = useState();

   console.log("ketqua: ", products)

    const onDelete = (id) => {
      
        let tasks = localStore;
        console.log("id la: ",id);
        localStore.forEach((task, index) => {
            if (task.id === id) {
                console.log("index",index);
                tasks.splice(index, 1);
                setProducts({ products: tasks });
                localStorage.setItem('products', JSON.stringify(tasks));
            } 
        });
    }

   
    //Update
    const setShowModal = (id) => {
        setModal(!modal);
        
    }

    const dataUpdate = (id) => {
        localStore.forEach((task, index) => {
            if (task.id === id) {
               setIdData({
                   idData:index
               })
               setData({
                   data:task
               })
            } 
        });
    }
    return (
        <>
            <h1 style={{ textAlign: "center" }}>List</h1>
            <div className="list-content">
                <table style={{ borderRadius: "5px", borderCollapse: "collapse", overflow: "hidden" }} className="table table-striped table-active">
                    <thead >
                        <tr>
                            <th scope="col">STT</th>
                            <th scope="col">Location</th>
                            <th scope="col">Date</th>
                            <th scope="col">Price</th>
                            <th scope="col">Image</th>
                            <th scope="col">Handle</th>
                        </tr>
                    </thead>
                    <tbody>
                        {localStore&&localStore.map((item, index) => {
                            return (
                                <tr key={index}>
                                    <th scope="row">{index + 1}</th>
                                    <td>{item.name}</td>
                                    <td>{item.date}</td>
                                    <td>{item.price}</td>
                                    <td><img alt="hinh" src={process.env.PUBLIC_URL + item.url} width="90" height="65" className="rounded" /></td>
                                    <td>
                                        <button
                                            className="btn btn-success"
                                            onClick={() => {
                                                setShowModal(item.id);
                                                dataUpdate(item.id);
                                            }}
                                        >Update</button>
                                        <button
                                            className="btn btn-danger"
                                            style={{ marginLeft: "10px" }}
                                            onClick={() => onDelete(item.id)}
                                        >Delete</button>
                                    </td>
                                </tr>
                            );
                        })}
                    </tbody>
                </table>
                {modal&&<ModalUpdate showModal={modal} setShowModal={setShowModal} data={data} idData={idData}/>}
            </div>
        </>
    );
}

export default AdminList
