﻿---frmBILL

--Tao ma HD
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
create function fTaoMaHoaDon()
returns char(6)
As
Begin
	Declare @MaHoaDon char(6)
	Set @MaHoaDon = (Select MAX(MaHoaDonBan) from HoaDonBanHang)
	
	if(@MaHoaDon is Null)
	begin
		Set @MaHoaDon = 1
		set @MaHoaDon=( REPLICATE('0',6-LEN(RTRIM(@MaHoaDon))) + RTRIM(@MaHoaDon))
		return @MaHoaDon
	end

	Set @MaHoaDon = @MaHoaDon + 1
	set @MaHoaDon=( REPLICATE('0',6-LEN(RTRIM(@MaHoaDon))) + RTRIM(@MaHoaDon))
	return @MaHoaDon
end	
select dbo.fTaoMaHoaDon()
select * from HoaDonBanHang


--Lấy tổng tiền
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
create function fTongtien(@MaHD char(6))
returns numeric(15,0)
As
Begin
	declare @sum numeric(15,0)
	set @sum = (select sum(ThanhTien) from ChiTietHoaDonBanHang where MaHoaDonBan = @MaHD)
	return @sum
end	


--insert hóa đơn
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
Create proc spInsertHoaDon @MaHD varchar(6), @MaTK varchar(50), @NgayBan date
as
begin
	insert into HoaDonBanHang(MaHoaDonBan,MaTK,NgayBan)
	values (@MaHD,@MaTK,@NgayBan)
end

select * from hoadonbanhang

-- insert chi tiết hóa đơn
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
create proc spInsertChiTietHoaDonBanHang( @MaMon char (6),@SoLuong int)
as
begin
	declare @ThanhTien numeric(15,0), @maHD varchar(6)
	Set @maHD = (select max(MaHoaDonBan) from HoaDonBanHang)
	Set @ThanhTien = @SoLuong * (Select DonGia from Mon where MaMon = @MaMon)
	insert into ChiTietHoaDonBanHang(MaHoaDonBan,MaMon,SoLuong,ThanhTien)
	values (@MaHD,@MaMon,@SoLuong,@ThanhTien)
end


-- setbillinfolist
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
create proc spbillinfolist @maHD char(6)
as
begin
	select ChiTietHoaDonBanHang.MaMon as N'Mã Món', 
			Mon.TenMon as N'Tên Món', 
			ChiTietHoaDonBanHang.SoLuong as N'Số Lượng', 
			Mon.DonGia as N'Đơn Giá', 
			ChiTietHoaDonBanHang.ThanhTien as N'Thành Tiền'
	from HoaDonBanHang inner join ChiTietHoaDonBanHang on HoaDonBanHang.MaHoaDonBan = ChiTietHoaDonBanHang.MaHoaDonBan
						inner join Mon on Mon.MaMon = ChiTietHoaDonBanHang.MaMon
	where ChiTietHoaDonBanHang.MaHoaDonBan = @maHD
end
go


--getmamon
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
create proc spgetmamon @MaMon varchar(6)
as
begin
	select * from ChiTietHoaDonBanHang where MaHoaDonBan = (select Max(MaHoaDonBan) from HoaDonBanHang) and MaMon = @MaMon
end



--- Trùng món
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
create proc sptrungmon @maMon nvarchar(6), @soLuong int
as
begin
	update ChiTietHoaDonBanHang 
	set SoLuong = SoLuong + @soLuong, ThanhTien = ThanhTien + @soLuong* (select DonGia from Mon where MaMon = @maMon)
	where MaHoaDonBan = (select Max(MaHoaDonBan) from HoaDonBanHang) and maMon = @maMon
end


--Delete billinfo
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
create proc spxoamon @maMon nvarchar(6)
as
begin
	delete from ChiTietHoaDonBanHang where MaHoaDonBan = (select Max(MaHoaDonBan) from HoaDonBanHang) and maMon = @maMon
end

select sum(thanhtien) from ChiTietHoaDonBanHang

--btnLuuHD
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
create proc spUpdateTongTien @maHD varchar(6)
as
begin
	declare @sum numeric(15,0)
	set @sum = (select sum(ThanhTien) from ChiTietHoaDonBanHang where MaHoaDonBan = @maHD)
	update HoaDonBanHang set TongTien = @sum where MaHoaDonBan = @maHD
end

--btnHuyHD
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
Create proc spDeleteHD (@maHD char(6))
As
Begin
	Delete from ChiTietHoaDonBanHang where MaHoaDonBan = @maHD
	Delete from HoaDonBanHang where MaHoaDonBan = @maHD
End