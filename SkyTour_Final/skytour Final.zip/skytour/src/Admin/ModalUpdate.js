import React, { useRef, useState, useEffect } from 'react'
import { Modal, ModalHeader, ModalBody, ModalFooter } from 'reactstrap';
import "../Styles/ModalUpdate.css";

function ModalUpdate(props) {
    let localStore = JSON.parse(localStorage.getItem('products'));
    const isOpen = props.showModal;
    const setShowModal = props.setShowModal;
    const dataUpdate = props.data.data;
    const idData = props.idData.idData;
    console.log("idata:", idData);
    const fileInputRef = useRef();
    const submitRef = useRef();
    const [image, setImage] = useState();
    const [preview, setPreview] = useState();
    const [value, setValue] = useState({
        id: dataUpdate.id,
        name: dataUpdate.name,
        date: dataUpdate.date,
        url: dataUpdate.url,
        description: dataUpdate.description,
        price:dataUpdate.price,
    });


    useEffect(() => {
        //img
        if (image) {
            const reader = new FileReader();
            reader.onloadend = () => {
                setPreview(reader.result);
            }
            reader.readAsDataURL(image);
        } else {
            setPreview(null);
        }
    }, [image]);

    const onChooseImgae = (event) => {
        event.preventDefault();
        fileInputRef.current.click();
    }

    //change image
    const handleChangeImage = (event) => {
        const file = event.target.files[0];
        if (file && file.type.substr(0, 5) === "image") {
            setImage(file);
        } else {
            setImage(null);
        }
    }

    const handleInputChange = (event) => {
        setValue({
            ...value,
            [event.target.name]: event.target.value,
        })
    }

    const clearForm = () => {
        setValue({
            id: "",
            name: "",
            date: "",
            url: "",
            description: "",
            price:"",
        })
    }
    const handleSubmitUpdate = (event) => {
        event.preventDefault();
        let myImage
        if(preview){
            myImage=preview;
        }else{
            myImage=value.url;
        }
        //alert("name: " + value.name + "\ndate: " + value.date + "\nurl: " + myImage + "\ndesc: " + value.description);
        var tasks = localStore;
        tasks[idData] = value;
        tasks[idData].url=myImage;
        console.log("value la: ",tasks[idData])
        localStorage.setItem('products', JSON.stringify(tasks));
        clearForm();
        setShowModal();
    }

    return (
        <>
            <Modal isOpen={isOpen}>
                <ModalHeader className="modal_update">Update Tickets</ModalHeader>
                <ModalBody>
                    <form onSubmit={handleSubmitUpdate}>
                        <input
                            className="myInput"
                            placeholder="Location"
                            name="name"
                            value={value.name}
                            onChange={handleInputChange}
                        />
                        <input
                            className="myInput"
                            type="date"
                            name="date"
                            onChange={handleInputChange}
                            value={value.date}
                        />
                        <input
                            className="myInput"
                            name="price"
                            onChange={handleInputChange}
                            value={value.price}
                        />
                        <button className="button-update" onClick={onChooseImgae}>Choose Image</button>
                        <input
                            ref={fileInputRef}
                            style={{ display: 'none' }}
                            type="file"
                            accept="image/*"
                            onChange={(event) => {
                                handleChangeImage(event);
                                handleInputChange(event);
                            }}
                            name="url"
                        />
                        {preview ? <img className="myImage" src={preview} alt="yourImage" /> :
                            <img className="myImage" src={process.env.PUBLIC_URL + dataUpdate.url} alt="yourImage" />}

                        <textarea
                            className="myInput myArea"
                            placeholder="Description..."
                            name="description"
                            onChange={handleInputChange}
                            value={value.description}
                        ></textarea>
                        <button type="submit" ref={submitRef} style={{ display: "none" }}></button>
                    </form>
                </ModalBody>
                <ModalFooter>
                    <button className="button-submit" onClick={() => submitRef.current.click()}>Update</button>
                    {/* <button className="button-submit" onClick={() => setShowModal(prevState => !prevState)} >Cancel</button> */}
                    <button className="button-submit" onClick={setShowModal} >Cancel</button>
                </ModalFooter>
            </Modal>
        </>
    )
}

export default ModalUpdate
