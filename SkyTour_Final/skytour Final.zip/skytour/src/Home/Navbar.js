import React, { useState } from 'react'
import { Link } from 'react-router-dom'
import Login from './Login';
import '../Styles/HomeNavbar.css';

function Navbar() {
    const [show, setShow] = useState(false);

    const handleLogin = () => {
        setShow(!show);
    }
    return (
        <nav className="my_nav">
            <div className="container1">
                <h3 style={{ color: "white" }}>Skytours</h3>

                <div className="menu">
                    <a href="#home_page">HOME</a>
                    <a href="#about_page">ABOUT</a>
                    <a href="#tours_page">TOURS</a>
                    <a href="#contact_page">CONTACT</a>
                    <Link to="/admin">ADMIN</Link>
                    <Link to="/" onClick={handleLogin}>LOGIN</Link>
                </div>
                <Login isShow={show} setShow={handleLogin} />

                <button className="nav_ctrl">
                    <span></span>
                    <span></span>
                    <span></span>
                </button>
            </div>
        </nav>
    );
}

export default Navbar
