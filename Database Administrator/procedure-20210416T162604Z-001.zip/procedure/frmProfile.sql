﻿
--frmProfile

--Change_pass
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROC USP_ChangePass
@userName NVARCHAR(100), @password NVARCHAR(100), @newPassword NVARCHAR(100)
AS
BEGIN
	DECLARE @isRightPass INT = 0
	
	SELECT @isRightPass = COUNT(*) FROM TaiKhoan WHERE MaTK = @userName AND MatKhau = @password
	
	IF (@isRightPass = 1)
	BEGIN
		
			UPDATE TaiKhoan SET MatKhau = @newPassword WHERE MaTK = @userName
	end
END
GO


--update
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROC USP_UpdateAccount @matk nvarchar(100), @hoten NVARCHAR(100), @sdt NVARCHAR(50), @diachi NVARCHAR(50)
AS
BEGIN
	UPDATE TaiKhoan SET HoTen = @hoten, SDT=@sdt, DiaChi=@diachi WHERE MaTK = @matk
END
GO  