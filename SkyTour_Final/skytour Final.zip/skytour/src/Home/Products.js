import React, { Component } from 'react';
import * as AiIcons from 'react-icons/ai';
import {
    Card, CardImg, CardText, Button, CardBody,
    CardTitle, Col, Row
} from 'reactstrap';
import { Link, Route } from 'react-router-dom';

import "../Styles/Product.css";
import '../Styles/Modals.css';
import Modals from './Modals';
import Detail from './Detail';

class Products extends Component {
    constructor(props) {
        super();
        this.state = {
            detailIsOpen: false,
            modalIsOpen: false,
            products: [],
        };
    }

    componentDidMount() {
        if (localStorage && localStorage.getItem('products')) {
            var products = JSON.parse(localStorage.getItem('products'));
            this.setState({
                products: products
            });
        }
        //console.log("du lieu nhan ve: ", this.props.onSubmit3);
    }
    productData = () => {
        var products = [
            {
                id: "1",
                name: "Đà Nẵng",
                date: "2021-08-19",
                url: "https://elead.com.vn/wp-content/uploads/2020/04/hinh-nen-full-hd-1080-cay-cau-dep-lung-linh_022855157-3.jpg",
                description: "đây là đà nẵng",
                price:"200000",
            }, {
                id: "2",
                name: "TP. HCM",
                date: "2021-07-19",
                url: "https://elead.com.vn/wp-content/uploads/2020/04/hinh-nen-full-hd-1080-bong-hoa-dep_022854518-3.jpg",
                description: "đây là Thành Phố Hồ Chí Minh",
                price:"250000",
            }, {
                id: "3",
                name: "Hội An",
                date: "2021-01-19",
                url: "https://msmobile.com.vn/upload_images/images/hinh-nen-dep-cho-may-tinh-full-hd-3.jpg",
                description: "đây là đà Hội An",
                price:"350000",
            }
        ];
        this.setState({
            products: products
        });
        localStorage.setItem('products', JSON.stringify(products));
    }


    setShowModal = (event) => {
        console.log("tim id", event);
        this.setState(prevState => ({
            modalIsOpen: !prevState.modalIsOpen
        }))
    }

    setShowDetail = () => {
        this.setState(prevState => ({
            detailIsOpen: !prevState.detailIsOpen
        }))
    }
    // themdulieu = () => {
    //     //do chua lay dc url anh tu admin nen random do nha ^^
    //     var value = this.props.onSubmit3;
    //     console.log("bandau",value);
    //     if (value!==undefined) {
    //         const { products } = this.state;
    //         value.id = this.randomID;
    //         value.url = this.randomImage;
    //         products.push(value);
    //         value=undefined;
    //         this.setState({
    //             products: products
    //         });
    //         localStorage.setItem('products', JSON.stringify(products));
    //         console.log("setup",value);
    //     } else {
    //         console.log("konhan dc",value);
    //         return;
    //     }
    // }



    render() {
        const { products } = this.state;
        const { match } = this.props;
        let url = match.url;

        return (
            <>
                <div className="bg_products" id="tours_page">
                    <AiIcons.AiOutlineReload onClick={this.productData} style={{ color: "white", cursor: "pointer" }} />
                    <div>
                        <h3 className="text-center text-white" style={{ marginTop: "40px" }}>TOUR DATES</h3><br />
                        <p className="text-center text-white fst-italic" style={{ marginBottom: "2px" }}>Lorem ipsum we'll play you some music.</p>
                        <p className="text-center text-white fst-italic" style={{ marginTop: "2px", marginBottom: "3px" }}>Remember to book your tickets!</p>
                    </div>
                    <div className="products_list" >
                        <Row>
                            {products.map((product, index) => {
                                return (
                                    <Col sm="4" key={product.id}>
                                        <Card>
                                            <Link to={`${url}${product.id}`} onClick={this.setShowDetail}>
                                                <CardImg top width="100%" src={product.url} />
                                            </Link>
                                            <CardBody>
                                                <CardTitle tag="h5">{product.name}</CardTitle>
                                                <CardText>{product.date}</CardText>
                                                <Button onClick={() => this.setShowModal(product.name)}>Buy Tickets</Button>
                                            </CardBody>
                                        </Card>
                                    </Col>
                                );
                            })}
                        </Row>
                        <Modals showModal={this.state.modalIsOpen} setShowModal={this.setShowModal} />
                        <Route path="/:id" render={({ match }) => <Detail showDetail={this.state.detailIsOpen} setShowDetail={this.setShowDetail} match={match} />} />
                        {/* <Route path="/:id" render={({ match }) => <Detail match={match} />}/> */}
                    </div>
                    <div className="pagination" style={{height:"60px"}}></div>
                </div>
            </>


        )
    }
}

export default Products;
