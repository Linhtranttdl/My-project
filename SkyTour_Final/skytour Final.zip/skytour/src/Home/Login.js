import React, { useState } from 'react'
import { Modal, ModalHeader, ModalBody, ModalFooter } from 'reactstrap';
import '../Styles/Login.css';
//import { Redirect } from 'react-router-dom';

const LoginForm = () => {
    let users = JSON.parse(localStorage.getItem('users'));
    const [loginValue, setLoginValue] = useState({
        name: "",
        pass: "",
    });

    const handleLoginInputChange = (event) => {
        setLoginValue({
            ...loginValue,
            [event.target.name]: event.target.value,
        })
    }
    const ClearForm=()=>{
       setLoginValue({
        name: "",
        pass: "",
       })
    }

    const handleLoginSubmit = (event) => {
        event.preventDefault();
        users&&users.forEach(function (user) {
            if (user.name === loginValue.name && user.pass===loginValue.pass) 
             alert("thanh cong");
             ClearForm();
              return;
          });       
    }
    return (
        <form onSubmit={handleLoginSubmit}>
            <input
                placeholder="Login name"
                name="name"
                value={loginValue.name}
                onChange={handleLoginInputChange}
            />
            <input
                 type="password"
                placeholder="Password"
                name="pass"
                onChange={handleLoginInputChange}
                value={loginValue.pass}
            />
            <button type="submit">Login</button>
        </form>
    );
}

const RegistrationFrom = () => {
    const [resValue, setResValue] = useState({
        name: "",
        pass: "",
        confirm: "",
    });



    const handleResInputChange = (event) => {
        setResValue({
            ...resValue,
            [event.target.name]: event.target.value,
        })
    }


    const ClearForm =()=>{
        setResValue({
            name: "",
            pass: "",
            confirm: "",
        })
    }
    const handleResSubmit = (event) => {
        event.preventDefault();
        if(resValue.pass!==resValue.confirm){
            alert("mat khau sai...");
            ClearForm();
            return;
        }
        //alert("Name: " + resValue.name + "\nPass: " + resValue.pass + "\nvalidate pass: " + resValue.confirm);       
        const user = {
            name: resValue.name,
            pass: resValue.pass,
        }
        let users = localStorage.getItem('users');
        if (users) {
            users = JSON.parse(users);
            users.push(user)
            localStorage.setItem('users', JSON.stringify(users))
        } else {
            users = [user];
            localStorage.setItem('users', JSON.stringify(users))
        }
        ClearForm();

    }
        return (
            <form onSubmit={handleResSubmit}>
                <input
                    placeholder="Login name"
                    onChange={handleResInputChange}
                    name="name"
                    value={resValue.name}
                />
                <input 
                    placeholder="Password"
                    type="password"
                    onChange={handleResInputChange}
                    name="pass"
                    value={resValue.pass}
                />
                <input
                    placeholder="Confirm password"
                    type="password"
                    onChange={handleResInputChange}
                    name="confirm"    
                    value={resValue.confirm}
                />
                <button>Register</button>
            </form>
        );
    }


function Login(props) {
    const { isShow, setShow } = props
    const [logOrRes, setLogOrRes] = useState(true);

    const handleLoginOrRes = () => {
        setLogOrRes(!logOrRes);
    }

    return (
        <>
            <Modal isOpen={isShow}>
                <ModalHeader>{logOrRes ? "Login" : "Sign Up"}</ModalHeader>
                <ModalBody className='login_body'>
                    {logOrRes ? <LoginForm /> : <RegistrationFrom />}
                </ModalBody>
                <ModalFooter className='login_footer'>
                    <button onClick={handleLoginOrRes}>{logOrRes ? "Sign Up" : "Login Page"}</button>
                    <button onClick={setShow}>Cancel</button>
                </ModalFooter>
            </Modal>

        </>
    )
}

export default Login
