﻿
---update
create proc TaiKhoan_Update(
	@MaTK varchar(50),
	@MatKhau varchar(100),
	@HoTen nvarchar(50),
	@SDT varchar(15),
	@ChucVu nvarchar(50),
	@DiaChi nvarchar(200))
as
begin
	
		update TaiKhoan set MatKhau=@MatKhau, HoTen=@HoTen, SDT=@SDT, DiaChi=@DiaChi, ChucVu=@ChucVu where MaTK=@MaTK
end

--insert

create proc spInsertTaiKhoan(@MaTK varchar(50),@MatKhau varchar(50),@HoTen nvarchar(100),@SDT varchar(15), @ChucVu nvarchar(50),@DiaChi nvarchar(200))
as
begin
	declare @checkMaTK int = 0

	Set @checkMaTK = (Select COUNT(MaTK) from TaiKhoan where MaTK = @MaTK)

	if(@checkMaTK != 0)
	begin
		return 
	end

	insert into TaiKhoan(MaTK,MatKhau,HoTen,SDT,ChucVu,DiaChi)
	values (@MaTK,@MatKhau,@HoTen,@SDT,@ChucVu,@DiaChi)
end

---Xoa
Create trigger tDeleteTaiKhoan
on TaiKhoan
Instead of delete
as
begin
	update TaiKhoan
	set ChucVu = N'Không tồn tại'
	from deleted
	Where TaiKhoan.MaTK = deleted.MaTK
end