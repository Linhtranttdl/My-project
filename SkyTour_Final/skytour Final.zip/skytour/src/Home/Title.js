import React, { useState } from 'react'
import PropTypes from 'prop-types'
import "../Styles/ngan.css"
const Title = props => {
    const band = props.bandProps
    //console.log("ket qua la: ", band.infor)
    const [isOpen, setIsOpen] = useState(false)

    const handleShowDetail = () => {
        setIsOpen(!isOpen);
    }

    return (
        <>
            <div className="col-sm-4">
                <p className="text-center">
                    <strong style={{ color: "#777" }}>{band.title}</strong>
                </p> <br />
                <div>
                    <img onClick={handleShowDetail}
                        src={band.img}
                        className="img-circle person rounded-circle"
                        alt="Sky Tour"
                        data-toggle="collapse" />
                </div>
                <div>
                    <div className={isOpen ? "transiton1 transiton2" : "transiton1"}>{band.infor}</div>
                </div>
            </div>
        </>
    )
}

//PropTypes
Title.propTypes = {
    bandProps: PropTypes.object.isRequired,
}

export default Title
