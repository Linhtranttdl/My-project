
import React, { Component } from "react"
import '../Styles/Contact.css';
import '../Styles/Responsive.css';



class Contact extends Component {
    constructor(props) {
        super(props)

        this.state = {
            name: '',
            email: '',
            message: '',
           validate: "",
        }

    }

    validateFrom = () => {
        const msg = {};
        if (this.state.name === "" || this.state.name.trim() === "") {
            msg.name = "Name can not be blank"
        }
        if (this.state.email === "" || this.state.email === null || this.state.email === undefined || !this.state.email.includes('@')) {
            msg.email = 'Invalid email';
        }
        if (this.state.message.length < 20) {
            msg.message = "Message must has more than 20 characters"
        }
        this.setState({
            validate: msg
        })
        //chuyen Object thành Array
        if (Object.keys(msg).length > 0) return false;
        return true;
    }




    handleInputChange = (e) => {
        const target = e.target;
        const name = target.name;
        const value = target.value;

        this.setState({
            [name]: value
        });
    }
    //hàm này bằng ba hàm kia cộng lại


    clearForm = () => {
        this.setState({
            name: "",
            email: "",
            message: "",
            validate: ""

        })
    }

    handlerSubmit = event => {
        event.preventDefault();
        const validate = this.validateFrom();
        if (!validate) {
            return;
        }

        const { name, email, message } = this.state;
        const date = new Date();
        const myDate = `${date.getFullYear()}-${date.getUTCMonth()}-${date.getUTCDate()}`;
        const isRead = false;
        const randomID = Math.floor(Math.random() * 90000) + 1
        const contact = {
            id: randomID,
            name: name,
            email: email,
            message: message,
            isRead: isRead,
            date: myDate
        }

        let contacts = localStorage.getItem('contacts');
        if (contacts) {
            contacts = JSON.parse(contacts);
            contacts.push(contact)
            localStorage.setItem('contacts', JSON.stringify(contacts))
        } else {
            contacts = [contact];
            localStorage.setItem('contacts', JSON.stringify(contacts))
        }
        this.clearForm();
    }

    render() {
        const { validate } = this.state
        return (
            <div id="contact_page">
                <div className="content-section">
                    <h2 className="section-heading text-center">CONTACT</h2>
                    <p className="section-sub-heading text-center mt-16">Skyer? Drop a note!</p>

                    <div className="roww s-col-full contact-content">
                        <div className="col col-half s-col-full contact-info">
                            <p><i className="ti-location-pin"></i>Address: Quận 1, TP.Hồ Chí Minh</p>
                            <p><i className="ti-mobile"></i>Phone: 028 5410 2202</p>
                            <p><i className="ti-email"></i>Email: booking@mtpentertainment.com</p>
                        </div>

                        <div className="col col-half s-col-full contact-form">
                            <form onSubmit={this.handlerSubmit}>
                                <div className="roww">
                                    <div className="col s-col-full col-half">
                                        <input
                                            type='text'
                                            value={this.state.name}
                                            placeholder="Name"
                                            className="form-control"
                                            onChange={this.handleInputChange}
                                            name="name"
                                        />
                                        <div style={{ fontSize: 12, color: "red", fontStyle: "italic" }}>
                                            {validate.name}
                                        </div>
                                    </div>

                                    <div className="col s-col-full col-half s-mt-8 mb-8 ">
                                        <input
                                            type='text'
                                            value={this.state.email}
                                            placeholder="Email"
                                            className="form-control"
                                            onChange={this.handleInputChange} 
                                            name="email"/>
                                        <div style={{ fontSize: 12, color: "red", fontStyle: "italic" }}>
                                            {validate.email}
                                        </div>
                                    </div>
                                </div>

                                <div className="roww mt-8">
                                    <div className="col col-full">
                                        <textarea
                                            value={this.state.message}
                                            placeholder="Message"
                                            className="form-control"
                                            onChange={this.handleInputChange} 
                                            name="message"/>
                                        <div style={{ fontSize: 12, color: "red", fontStyle: "italic" }}>
                                            {validate.message}
                                        </div>
                                    </div>
                                </div>
                                <button type="submit" className="form-submit-btn mt-16 s-full-width mb-64">SEND</button>
                            </form>
                        </div>

                    </div>
                </div>
            </div>

        )
    }

}

export default Contact




