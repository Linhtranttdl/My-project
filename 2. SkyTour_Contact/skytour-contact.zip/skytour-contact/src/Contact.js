import React, {Component} from "react"
import './Contact.css'

class Contact extends Component{
    constructor(props) {
        super(props)

        this.state = {
            name: '',
            email: '',
            message: ''
        }

    }

    handlerNameChange = (event) => {
        this.setState({
            name: event.target.value
        })
    }

    handlerEmailChange = (event) => {
        this.setState({
            email: event.target.value
        })
    }

    handlerMessageChange = (event) => {
        this.setState({
            message: event.target.value
        })
    }

    handlerSubmit = event => {
        alert(`${this.state.name} ${this.state.email} ${this.state.message}`)
        event.preventDefault()
    }



    render(){
        const { name, email, message} = this.state
        return(
            <div>
            <div className="content-section ">
                <h2 className="section-heading text-center">CONTACT</h2>
                <p className="section-sub-heading text-center mt-16">Skyer? Drop a note!</p>

                <div className="row  contact-content">
                    <div className="col col-half contact-info">
                        <p><i className="ti-location-pin"></i>Address: Quận 1, TP.Hồ Chí Minh</p>
                        <p><i className="ti-mobile"></i>Phone: 028 5410 2202</p>
                        <p><i className="ti-email"></i>Email: booking@mtpentertainment.com</p>
                        
                    </div>

                    <div className="col col-half contact-form">
                        <form onSubmit={this.handlerSubmit}>
                            <div className="row">
                                <div className="col col-half">
                                    <input type='text' value={name} placeholder="Name" className="form-control"
                                    onChange={this.handlerNameChange} />
                                </div>

                                <div className="col col-half">
                                    <input type='text' value={email} placeholder="Email" className="form-control"
                                    onChange={this.handlerEmailChange} />

                                </div>   
                            </div>

                            <div className="row mt-8">
                                <div className="col col-full">
                                    <textarea value={message} placeholder="Message" className="form-control"
                                    onChange={this.handlerMessageChange}></textarea>  
                                </div>
                            </div>
                            <button type="submit" className="form-submit-btn mt-16">SEND</button>
                        </form>
                    </div>

                </div>
            </div>
                {/* <div className="content-footer">
                    <div className="col col-third ">
                        <img src="./img/Muon.jpg" className="content-pic">
                        </img>

                    </div>
                </div> */}
            </div>
           
        )
    }

}

export default Contact