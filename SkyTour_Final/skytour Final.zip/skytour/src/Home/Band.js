import React from 'react';
import Title from './Title';
import "../Styles/ngan.css"

const Band = () => {
    const bandState = ([
        {
            id: 1,
            title: 'Sky Music',
            img: "https://i.pinimg.com/564x/86/d7/5b/86d75b0705576a58e5433e72795c3bfd.jpg",
            infor: 'Âm nhạc của Sơn Tùng M-TP trong Sky Tour bao gồm những ca khúc được chọn lọc lẫn các ca khúc mới. Kết hợp với'
                + ' kỹ thuật dàn dựng, hệ thống âm thanh, ánh sáng đạt chuẩn quốc tế. Hứa hẹn sẽ đẩy cảm xúc của khán giả bùng nổ và thăng hoa nhất.',
            collapsible: false
        },
        {
            id: 2,
            title: 'Son Tung M-TP',
            img: "https://i.pinimg.com/564x/dc/f3/1e/dcf31e5f61b44c894b75a6fad9db5a67.jpg",
            infor: 'Sơn Tùng M-TP dành thời gian dài làm việc với các producer để cho ra đời những "chiếc áo hoàn toàn mới" của loạt hit đình đám. '
                + 'Đặc biệt, mỗi đêm diễn sẽ có loạt khách mời đình đám và thời gian giao lưu cùng fans sẽ luôn là những ẩn số bất ngờ và thú vị',
            collapsible: false
        },
        {
            id: 3,
            title: 'Sky Tour',
            img: "https://i.pinimg.com/564x/fe/74/71/fe7471a7313d4624ba4a18bd4b6b1d99.jpg",
            infor: 'Sky Tour - Website giúp bạn chạm chân đến âm nhạc của Sơn Tùng M-TP một cách nhanh và an toàn nhất. '
                + 'Chỉ cần nhấn đăng ký và đặt vé, bạn đã có một chỗ ưu thích và phù hợp để có những trải nghiệm cùng những giây phút tuyệt vời trong Sky Tour',
            collapsible: false
        },
    ])
   

    return (
        <div style={{width:"58%",margin:"auto"}} id="about_page">
        <section id='band' className='container text-center'>
            <div>
                <h3>ABOUT SKY TOUR</h3>
                <p><em style={{color:"#777"}}>"Sky oi!!!"</em></p>
                <p><em style={{color:"#777"}}>Say: "Oh Yeah"</em></p>
                <p style={{color:"#777"}}>Sky Tour nơi âm nhạc được lan tỏa, nơi ta cháy cùng Sơn Tùng M-TP</p>
                <br />
            </div >
            <div className="row">
                {bandState.map(band => {
                    return <Title key={band.id} bandProps={band} />
                })}
            </div>
        </section>
        </div>

    )
}

export default Band

