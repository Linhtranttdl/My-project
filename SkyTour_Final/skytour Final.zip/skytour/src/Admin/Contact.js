import React, { useState } from 'react'
import "../Styles/List.css"
import ModalContact from './ModalContact';

function Contact() {
    let localStore = JSON.parse(localStorage.getItem('contacts'));
    const [contacts, setContact] = useState(localStore);

    const [modal, setModal] = useState(false); //modal
    const [data, setData] = useState({});//modal
    const [idData, setIdData] = useState();//modal

    console.log(contacts);
    const onDelete = (id) => {
        let tasks = localStore;
        localStore.forEach((task, index) => {
            if (task.id === id) {
                tasks.splice(index, 1);
                setContact({ contacts: tasks });
                localStorage.setItem('contacts', JSON.stringify(tasks));
            }
        });
    }

    const setShowModal = (id) => {
        setModal(!modal);
    }

    const onReply = (id) => {
        localStore.forEach((task, index) => {
            if (task.id === id) {
                setIdData({
                    idData: index
                })
                setData({
                    data: task
                })
            }
        });
    }



    return (
        <>
            <h1 style={{ textAlign: "center" }}>Contact</h1>
            <div className="list-content">
                <table style={{ borderRadius: "5px", borderCollapse: "collapse", overflow: "hidden" }} className="table table-striped table-active">
                    <thead >
                        <tr>
                            <th scope="col">STT</th>
                            <th scope="col">Name</th>
                            <th scope="col">Email</th>
                            <th scope="col">Message</th>
                            <th scope="col"></th>
                        </tr>
                    </thead>
                    <tbody>
                        {localStore && localStore.map((item, index) => {
                            return (
                                <tr key={index}>
                                    <th scope="row">{index + 1}</th>
                                    <td>{item.name}</td>
                                    <td>{item.email}</td>
                                    <td>{item.message}</td>
                                    <td>
                                        <button
                                            className="btn btn-success"
                                            onClick={() => {
                                                setShowModal(item.id);
                                                onReply(item.id);
                                            }}
                                        >Reply</button>
                                        <button
                                            className="btn btn-danger"
                                            style={{ marginLeft: "10px" }}
                                            onClick={() => onDelete(item.id)}
                                        >Delete</button>
                                    </td>
                                </tr>
                            );
                        })}
                    </tbody>
                </table>
                {modal && <ModalContact showModal={modal} setShowModal={setShowModal} data={data} idData={idData} />}
            </div>
        </>
    )
}

export default Contact
