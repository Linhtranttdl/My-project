import React from 'react';
import { Carousel } from 'react-bootstrap';


function HomeCarousel() {

    const Slides = ([
        {
            id: 1,
            img: "/photo/banner1.jpg",
            text1: "Có Chắc yêu là đây",
            text2: "Điều anh luôn giữ kín trong tim, giữ mãi trong tim, giữ mãi trong tim...",
        },
        {
            id: 2,
            img: "/photo/banner2.jpg",
            text1: "Muộn rồi mà sao còn",
            text2: "Có ai thương lắng lo cho em ?",
        },
        {
            id: 3,
            img: "/photo/banner3.jpg",
            text1: "Hãy trao cho anh",
            text2: "Cho em...",
        },
        {
            id: 4,
            img: "/photo/banner4.jpg",
            text1: "Làm người luôn yêu em",
            text2: "Thương em đôi mắt ướt nhòa",
        },
    ])

    return (
        <div id="home_page">
            <Carousel>

                {Slides.map(slide => {
                    let myUrl=slide.img;
                    return (
                        <Carousel.Item key={slide.id}>
                            <img
                                className="d-block w-100"
                                src={process.env.PUBLIC_URL + myUrl}
                                alt="Hello"
                            />
                            <Carousel.Caption>
                                <h3>{slide.text1}</h3>
                                <p>{slide.text2}</p>
                            </Carousel.Caption>
                        </Carousel.Item>
                    );
                })}

            </Carousel>
        </div>
    )
}

export default HomeCarousel
