﻿
--update
create proc Menu_Update(
	@MaMon char(6),
	@TenMon nvarchar(100),
	@DonViTinh nvarchar(50),
	@DonGia numeric(15,0))
as
begin
	
		update Mon set TenMon=@TenMon, DonGia=@DonGia, DonViTinh=@DonViTinh where  MaMon=@MaMon
end


--tao ma mon
Create function fTaoMaMon()
 returns char(6)
 As
 Begin
	Declare @MaMon char(6)
	Set @MaMon = (Select MAX(MaMon) from Mon)

	if(@MaMon is Null)
	begin
		Set @MaMon = 1
		set @MaMon=( REPLICATE('0',6-LEN(RTRIM(@MaMon))) + RTRIM(@MaMon))
		return @MaMon
	end

	Set @MaMon = @MaMon + 1
	set @MaMon=( REPLICATE('0',6-LEN(RTRIM(@MaMon))) + RTRIM(@MaMon))
	return @MaMon
 end

--insert
Create proc spInsertMon(@MaMon char(6), @TenMon nvarchar(100),@DonGia numeric(15,0),@DonViTinh nvarchar(50))
as
begin
	declare @checkMaMon int
	Set @checkMaMon = (select COUNT(MaMon) from Mon where MaMon = @MaMon)
	if(@checkMaMon > 1)
	begin
		return
	end

	insert into Mon(MaMon,TenMon,DonGia,DonViTinh)
	values (@MaMon,@TenMon,@DonGia,@DonViTinh)
end


--xoa
Create trigger tDeleteMon
on Mon
Instead of delete
as
begin
	update Mon
	set DonGia = -1
	from deleted
	Where Mon.MaMon = deleted.MaMon
end


