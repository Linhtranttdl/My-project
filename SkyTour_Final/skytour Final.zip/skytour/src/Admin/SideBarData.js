import React from 'react'
//import * as FaIcons from "react-icons/fa";
import * as AiIcons from "react-icons/ai";
//import * as IoIcons from "react-icons/io";

export const SidebarData=[
    {
        title:'Home',
        path:'/',
        icon: <AiIcons.AiFillHome/>,
        cName:'nav-text1',
    },
    {
        title:'List',
        path:'/admin/list',
        icon: <AiIcons.AiFillAppstore/>,
        cName:'nav-text1',
    },
    {
        title:'Add',
        path:'/admin/add',
        icon: <AiIcons.AiFillFolderAdd/>,
        cName:'nav-text1',
    },
    {
        title:'Contact',
        path:'/admin/contact',
        icon: <AiIcons.AiFillCode/>,
        cName:'nav-text1',
    },


]
