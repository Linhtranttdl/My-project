import React, { useState } from 'react';
import './App.css';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import Home from './components/Home';
import Admin from './components/Admin';
import Menu from './components/Menu';


function App() {
  const [value, setValue] = useState("");
  const handleData = (data) => {
    console.log("app.js la: ", data);
    setValue({ value: data })
  }


  return (
    <Router>
      {/* <Menu /> */}
      <Switch>
        {/* <Route path="/" exact><Home onSubmit2={value}/></Route> */}
        <Route path="/admin" exact><Menu /><Admin onSubmit1={handleData} ></Admin></Route>
        <Route path="/" render={({ match }) => <Home match={match} onSubmit2={value} />} />
      </Switch>
    </Router>
  );
}

export default App;
