import React from 'react'
import { Link} from 'react-router-dom';
import * as AiIcons from "react-icons/ai";

function Menu(props) {
    return (
        <div style={{background:"#83C5BE", height:"1px"}}>
            <Link  to="/"><AiIcons.AiOutlineRollback style={{color:"white"}}/></Link>
        </div>
    )
}

export default Menu
