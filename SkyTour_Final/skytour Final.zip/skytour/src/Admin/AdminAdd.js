import React, { useEffect, useRef, useState } from 'react'
import '../Styles/AdminAdd.css'
// import nextId from "react-id-generator";

export default function AdminAdd(props) {

    //image
    const [image, setImage] = useState();
    const [alert, setAlert] = useState(false);
    const [validate, setValidate] = useState("");


    //ref
    const fileInputRef = useRef();
    const formRef = useRef();
    const inputNameRef = useRef();

    //preview
    const [preview, setPreview] = useState();

    //input value
    const [values, setValues] = useState({
        id: "",
        name: "",
        date: "",
        url: "",
        description: "",
        price:"",
    });
    //console.log("ket qua la: ",preview);
    // console.log(preview);
    useEffect(() => {
        //img
        if (image) {
            const reader = new FileReader();
            reader.onloadend = () => {
                setPreview(reader.result);
            }
            reader.readAsDataURL(image);
        } else {
            setPreview(null);
        }
    }, [image]);

    //validate form
    const validateFrom = () => {
        const msg = {};
        if (values.name === "" || values.name.trim() === "") {
            msg.location = "Please input your Location";
        }
        if (values.date === "" || values.date === null || values.date === undefined) {
            msg.date = "Please input your Date";
        }
        if (values.price === "" || values.price.trim() === "") {
            msg.price = "Please input your Price";
        }
        if (values.url === "" || values.url === null || values.url === undefined) {
            msg.url = "Please choose your image";
        }
        if (values.description === "" || values.description.trim() === "") {
            msg.description = "Please input your Description";
        }
        setValidate(msg);
        //chuyen Object thành Array
        if (Object.keys(msg).length > 0) return false;
        return true;
    }

    //submit
    const handleSubmit = (event) => {
        event.preventDefault();
        const validate = validateFrom();
        if (!validate) {
            setAlert({ alert: false });
            return;
        }

        // var products = JSON.parse(localStorage.getItem('products'));
        let products = localStorage.getItem('products');
        var randomID = Math.floor(Math.random() * 90000) + 1
        let product = {
            id: randomID.toString(),
            name: values.name,
            date: values.date,
            url: preview,
            description: values.description,
            price:values.price
        }
        if (products) {
            products = JSON.parse(products);
            products.push(product)
            localStorage.setItem('products', JSON.stringify(products))
        } else {
            products = [product];
            localStorage.setItem('products', JSON.stringify(products))
        }

        //products.push({ id: randomID.toString(), name: values.name, date: values.date, url: preview, description: values.description });


        localStorage.setItem('products', JSON.stringify(products));
        formRef.current.reset();
        onClearForm();
        inputNameRef.current.focus();
        setAlert({ alert: true });
        props.onSubmit(values);
    }

    //clear
    const onClearForm = () => {
        setValues({
            id: "",
            name: "",
            date: "",
            url: "",
            description: "",
            price:"",
        })
        setPreview({ preview: "" })
    }

    //change input
    const handleInputChange = (event) => {
        setValues({
            ...values,
            [event.target.name]: event.target.value,
        })
    }

    //click button "choose image"
    const handleClickButton = (event) => {
        event.preventDefault();
        fileInputRef.current.click();
    }

    //change image
    const handleChangeImage = (event) => {
        const file = event.target.files[0];
        if (file && file.type.substr(0, 5) === "image") {
            setImage(file);
        } else {
            setImage(null);
        }
    }

    return (
        <div className="admin-add">
            <h1 style={{ textAlign: "center" }}>Add Tickets</h1>
            <div className="content">
                {/* {console.log("alert cuoi",alert)} */}
                {alert.alert === true ? <div className="alert alert-success" role="alert">
                    Successfully added
                </div> : null}
                <form onSubmit={handleSubmit} ref={formRef}>
                    <label className="at">Location</label>
                    <input
                        className="add-input"
                        name="name"
                        onChange={handleInputChange}
                        ref={inputNameRef}
                    />
                    <p style={{ fontStyle: "italic" }} className="text-danger">{validate.location}</p>
                    <label>Date</label>
                    <input
                        type="date"
                        className="add-input"
                        name="date"
                        onChange={handleInputChange}
                    />
                    <p style={{ fontStyle: "italic" }} className="text-danger">{validate.date}</p>
                    <label className="at">Price</label>
                    <input
                        className="add-input"
                        name="price"
                        onChange={handleInputChange}
                    />
                    <p style={{ fontStyle: "italic" }} className="text-danger">{validate.price}</p>
                    <label>Photo</label>
                    <button onClick={handleClickButton}>Choose Image</button>
                    <input
                        style={{ display: "none" }}
                        type="file"
                        ref={fileInputRef}
                        accept="image/*"
                        onChange={(event) => {
                            handleChangeImage(event);
                            handleInputChange(event);
                        }}
                        name="url"
                    />
                    <p style={{ fontStyle: "italic" }} className="text-danger">{validate.url}</p>
                    {preview ? <img src={preview} alt="" /> : null}
                    <label>Description</label>
                    <textarea
                        className="add-input"
                        name="description"
                        onChange={handleInputChange}
                    />
                    <p style={{ fontStyle: "italic" }} className="text-danger">{validate.description}</p>
                    <input type="submit"></input>
                </form>
            </div>
        </div>
    );
}

