import React from 'react'
import Products from "../Home/Products";
import Band from '../Home/Band';
import Navbar from '../Home/Navbar';
import HomeCarousel from "../Home/HomeCarousel "
import Contact from "../Home/Contact"
import CarouselForm from '../Home/CarouselForm';
import Footer from "../Home/Footer";

function Home(props) {


    const data = props.onSubmit2;
    const match= props.match;
    return (
        <>
            <Navbar />
            <HomeCarousel />
            <Band/>
            <Products onSubmit3={data.value} match={match}/>
            <Contact/>
            <CarouselForm/>
            <Footer/>
        </>
    )
}

export default Home;
