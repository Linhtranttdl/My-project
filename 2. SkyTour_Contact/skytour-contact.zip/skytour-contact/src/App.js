import { Component } from 'react';
import './App.css';
import Contact from './Contact'

class App extends Component {
  render() {
    return (
      <div className="App">
        <Contact />
      </div>
    )
  }
}

export default App;
