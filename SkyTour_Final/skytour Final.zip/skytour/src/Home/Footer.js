
import React, {Component} from "react";
import * as FaIcons from 'react-icons/fa';
import * as AiIcons from 'react-icons/ai';
import * as GrIcons from 'react-icons/gr';

class Footer extends Component{
    render(){
        return(
            <div className="footer-contact">
                <FaIcons.FaFacebookSquare className="faceIcon"/>
                <AiIcons.AiOutlineInstagram className="InsIcon"/>
                <FaIcons.FaPinterestSquare className="prinIcon"/>
                <GrIcons.GrTwitter className="twIcon"/>
                <GrIcons.GrYoutube className="youtubeIcon"/>
            </div>
        )
    }
}
   

export default Footer