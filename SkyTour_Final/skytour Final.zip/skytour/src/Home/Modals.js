import React, { useState } from 'react'
import { Button, Modal, ModalHeader, ModalBody, ModalFooter } from 'reactstrap';


export default function Modals({ showModal, setShowModal }) {

    const [values, setValues] = useState({
        email: "",
        quantity: "",
    });


    const handleSubmit = (event) => {
        event.preventDefault();
        alert("Name: " + values.email +
            "\nQuantity: " + values.quantity
        );

    }

    const handleInputChange = (event) => {
        setValues({
            ...values,
            [event.target.name]: event.target.value,
        })
    }
    return (
        <>
            <Modal isOpen={showModal}>
                <ModalHeader>Tickets</ModalHeader>
                <ModalBody>
                    <form onSubmit={handleSubmit}>
                        <input onChange={handleInputChange} className="myInput" type="number" min="1" placeholder="how manny?" name="quantity" value={values.quantity}></input>
                        <input onChange={handleInputChange} className="myInput" placeholder="email ?" name="email" value={values.email}></input>
                        <Button type="submit" className="pay">Buy</Button>{' '}
                    </form>
                </ModalBody>
                <ModalFooter>
                    <Button onClick={() => setShowModal(prevState => !prevState)} >Cancel</Button>
                </ModalFooter>
            </Modal>

        </>

    )

}
