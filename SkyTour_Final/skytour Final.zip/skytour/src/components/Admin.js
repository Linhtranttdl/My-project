import React from 'react'
import { BrowserRouter as Router, Switch, Route } from "react-router-dom";
import Navbar from "../Admin/Navbar";
import AdminList from "../Admin/AdminList";
import AdminAdd from "../Admin/AdminAdd";
import Contact from "../Admin/Contact";

function Admin(props) {
    var onSubmit = (data) => {
        console.log("admin", data);
        props.onSubmit1(data);
    }
    return (
        <>
            <Router>
                <Navbar></Navbar>
                <Switch>
                    <Route path="/admin/list" exact component={AdminList}></Route>
                    <Route path="/admin/add" exact ><AdminAdd onSubmit={onSubmit} /></Route>
                    <Route path="/admin/contact" exact component={Contact}></Route>
                </Switch>
            </Router>
        </>
    )
}

export default Admin;
