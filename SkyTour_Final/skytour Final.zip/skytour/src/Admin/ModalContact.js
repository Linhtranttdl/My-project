import React, { useRef, useState } from 'react'
import { Modal, ModalHeader, ModalBody, ModalFooter } from 'reactstrap';
import emailjs from 'emailjs-com';

function ModalContact(props) {

    const [alert, setAlert] = useState(false);
    const submitRef = useRef();
    const { showModal, setShowModal } = props;
    const { data } = props.data;
    const { idData } = props.idData;
    console.log("IDdata: ", idData)

    const [value, setValue] = useState({
        name: data.name,
        toEmail: data.email,
        reply: "",
    });

    const handleInputChange = (event) => {
        setValue({
            ...value,
            [event.target.name]: event.target.value,
        })
    }

    const clearForm = () => {
        setValue({
            reply: ""
        });
    }

    const handleReply = (e) => {
        //  alert("Name: "+value.name +"\nEmail: "+value.email+"\nreply: "+value.reply);
        e.preventDefault();
        emailjs.sendForm('service_rqiqz52', 'template_p2enuvq', e.target, 'user_uJYuQCwvYrv2P8ea94Hib')
            .then((result) => {
                console.log(result.text);
            }, (error) => {
                console.log(error.text);
            });
        setAlert(true);
        clearForm();
    }
    
    return (
        <>
            <Modal isOpen={showModal}>
                <ModalHeader className="modal_update">Reply</ModalHeader>
                <ModalBody>
                    <form onSubmit={handleReply}>
                        {alert === true ? <div className="alert alert-success" role="alert" style={{width:"94%", margin:"auto", height:"55px"}} >
                            Successfully
                        </div> : null}

                        <input
                            className="myInput"
                            name="name"
                            value={value.name}
                            // onChange={handleInputChange}
                            readOnly
                        />
                        <input
                            className="myInput"
                            name="toEmail"
                            // onChange={handleInputChange}
                            value={value.toEmail}
                            readOnly
                        />

                        <textarea
                            className="myInput myArea"
                            placeholder="Reply..."
                            name="reply"
                            onChange={handleInputChange}
                            value={value.reply}
                        ></textarea>
                        <button type="submit" ref={submitRef} style={{ display: "none" }}></button>
                    </form>
                </ModalBody>
                <ModalFooter>
                    <button className="button-submit" onClick={() => submitRef.current.click()}>Reply</button>
                    <button className="button-submit" onClick={setShowModal} >Cancel</button>
                </ModalFooter>
            </Modal>
        </>
    )
}

export default ModalContact
