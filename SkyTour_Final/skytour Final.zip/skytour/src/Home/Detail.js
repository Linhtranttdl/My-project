import React, { useRef, useState, useEffect } from 'react';
import { Button, Modal, ModalHeader, ModalBody, ModalFooter } from 'reactstrap';
import { Link } from "react-router-dom";
import "../Styles/Detail.css";
import * as GoIcons from 'react-icons/go';
import * as ImIcons from 'react-icons/im';
import * as AiIcons from 'react-icons/ai';

function Detail(props) {

    let localStore = JSON.parse(localStorage.getItem('products'));
    const { match, showDetail, setShowDetail } = props
    const productID = match.params.id;
    const cancelRef = useRef();
    const [infor, setInfor] = useState(
        {
            id: "",
            url: "",
            name: "",
            date: "",
            description: "",
            price: "",
        }
    );
    const handleCancel = () => {
        cancelRef.current.click();
    }


    useEffect(() => {
        localStore && localStore.forEach((task, index) => {
            if (task.id === productID) {
                setInfor({
                    id: task.id,
                    url: task.url,
                    date: task.date,
                    name: task.name,
                    description: task.description,
                    price: task.price
                })
            }
        });
    }, []);


    return (
        <>
            <Modal isOpen={showDetail} className="detail_modal">
                <div className="modal_content">
                    <ModalHeader className="detail_header">Ticket Details</ModalHeader>
                    <ModalBody className="detail_body">
                        <div className="detail_img">
                            <img src={infor.url} alt="mtp" />
                        </div>
                        <div className="detail_content">

                            <div className="icon_ticket">
                                <GoIcons.GoLocation />
                                <h5>{infor.name}</h5><br></br>
                            </div>
                            <div className="icon_ticket">
                                <ImIcons.ImTicket />
                                <span>{infor.price} VND</span><br></br>
                            </div>
                            <div className="icon_ticket">
                                <AiIcons.AiOutlineFieldTime />
                                <span>{infor.date}</span><br></br>
                            </div>
                            <div className="icon_ticket">
                                <AiIcons.AiOutlineSend />
                                <span>{infor.description}</span>
                            </div>

                        </div>
                    </ModalBody>
                    <ModalFooter className="detail_footer">
                        <Button onClick={handleCancel} >Cancel</Button>
                        <Link style={{ display: 'none' }} ref={cancelRef} to="/" onClick={setShowDetail}>Cancel 2</Link>
                    </ModalFooter>
                </div>
            </Modal>

        </>
    )
}

export default Detail
